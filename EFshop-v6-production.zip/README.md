# EFshop v6 — Production backend starter

This package upgrades the EFshop v5 frontend from browser-only demo auth to a real backend architecture.

## Included
- Node.js + Express API
- PostgreSQL schema
- bcrypt password hashing
- HTTP-only session cookie with JWT
- Helmet security headers
- Login/register/logout/me endpoints
- Product API
- Authenticated orders using Player ID + Account ID
- Customer order history API
- Admin order/customer APIs
- No KONAMI/eFootball password collection

## Local setup
1. Install Node.js 20+ and PostgreSQL.
2. Create a database.
3. Run `database/schema.sql`.
4. Copy `.env.example` to `.env`.
5. Set DATABASE_URL and a strong JWT_SECRET.
6. `npm install`
7. `npm start`
8. Open http://localhost:3000

## Admin
The schema supports role=admin. Create a normal user first, then set that user's role to `admin` in PostgreSQL. Do not expose database credentials in frontend code.

## Production deployment
Deploy this Node app to a Node-compatible host and attach a managed PostgreSQL database. Set all environment variables in the host dashboard. Use HTTPS and keep database/JWT secrets server-side.

## Payment
The order endpoint records a transaction ID but does NOT pretend a payment was verified. For real bKash/Nagad/other gateway integration, add the provider's official server-side payment API + webhook/signature verification before changing an order to `paid`.

## Security
- Do not store passwords in localStorage.
- Do not collect KONAMI/eFootball passwords.
- Use HTTPS.
- Keep JWT secret and database URL out of Git.
- Add email verification, password reset, CSRF strategy, monitoring, backups and payment webhook verification before handling real money at scale.
