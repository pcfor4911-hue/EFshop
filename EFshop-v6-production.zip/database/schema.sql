CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  coins INTEGER NOT NULL CHECK (coins > 0),
  price_bdt INTEGER NOT NULL CHECK (price_bdt >= 0),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id BIGSERIAL PRIMARY KEY,
  order_no VARCHAR(40) UNIQUE NOT NULL,
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  product_id BIGINT NOT NULL REFERENCES products(id),
  player_id VARCHAR(80) NOT NULL,
  account_id VARCHAR(120) NOT NULL,
  payment_method VARCHAR(40) NOT NULL,
  transaction_id VARCHAR(160) NOT NULL,
  amount_bdt INTEGER NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending_payment',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

INSERT INTO products (name, coins, price_bdt)
SELECT '130 Coins', 130, 120
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='130 Coins');

INSERT INTO products (name, coins, price_bdt)
SELECT '550 Coins', 550, 490
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='550 Coins');

INSERT INTO products (name, coins, price_bdt)
SELECT '1,050 Coins', 1050, 890
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='1,050 Coins');
