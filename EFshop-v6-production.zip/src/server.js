import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";
import dotenv from "dotenv";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const { Pool } = pg;
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });

app.set("trust proxy", 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const orderLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false });

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function setAuthCookie(res, token) {
  res.cookie("efshop_session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/"
  });
}
function auth(req, res, next) {
  try {
    const token = req.cookies.efshop_session;
    if (!token) return res.status(401).json({ error: "Login required" });
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { return res.status(401).json({ error: "Invalid or expired session" }); }
}
function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required" });
  next();
}

app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true }); }
  catch { res.status(503).json({ ok: false }); }
});

app.post("/api/auth/register", authLimiter, async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password || password.length < 8) return res.status(400).json({ error: "Name, valid email and password (8+ chars) required" });
  const normalized = String(email).trim().toLowerCase();
  try {
    const exists = await pool.query("SELECT id FROM users WHERE email=$1", [normalized]);
    if (exists.rowCount) return res.status(409).json({ error: "Email already registered" });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email,role",
      [String(name).trim(), normalized, hash]
    );
    const user = result.rows[0];
    setAuthCookie(res, signToken(user));
    res.status(201).json({ user });
  } catch (e) { console.error(e); res.status(500).json({ error: "Registration failed" }); }
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "Email and password required" });
  try {
    const result = await pool.query("SELECT * FROM users WHERE email=$1", [String(email).trim().toLowerCase()]);
    if (!result.rowCount || !(await bcrypt.compare(password, result.rows[0].password_hash))) return res.status(401).json({ error: "Invalid email or password" });
    const u = result.rows[0];
    setAuthCookie(res, signToken(u));
    res.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
  } catch (e) { console.error(e); res.status(500).json({ error: "Login failed" }); }
});

app.post("/api/auth/logout", (_req, res) => {
  res.clearCookie("efshop_session", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/" });
  res.json({ ok: true });
});

app.get("/api/auth/me", auth, async (req, res) => {
  const r = await pool.query("SELECT id,name,email,role,created_at FROM users WHERE id=$1", [req.user.sub]);
  if (!r.rowCount) return res.status(401).json({ error: "User not found" });
  res.json({ user: r.rows[0] });
});

app.get("/api/products", async (_req, res) => {
  const r = await pool.query("SELECT id,name,coins,price_bdt FROM products WHERE active=true ORDER BY price_bdt");
  res.json({ products: r.rows });
});

app.post("/api/orders", orderLimiter, auth, async (req, res) => {
  const { productId, playerId, accountId, paymentMethod, transactionId } = req.body || {};
  if (!productId || !playerId || !accountId || !paymentMethod || !transactionId) return res.status(400).json({ error: "All checkout fields are required" });
  const p = await pool.query("SELECT id,price_bdt FROM products WHERE id=$1 AND active=true", [productId]);
  if (!p.rowCount) return res.status(404).json({ error: "Product not found" });
  const orderNo = "EFS-" + crypto.randomBytes(5).toString("hex").toUpperCase();
  const r = await pool.query(
    `INSERT INTO orders(order_no,user_id,product_id,player_id,account_id,payment_method,transaction_id,amount_bdt)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8)
     RETURNING order_no,status,amount_bdt,created_at`,
    [orderNo, req.user.sub, productId, String(playerId).trim(), String(accountId).trim(), String(paymentMethod).trim(), String(transactionId).trim(), p.rows[0].price_bdt]
  );
  res.status(201).json({ order: r.rows[0] });
});

app.get("/api/orders", auth, async (req, res) => {
  const r = await pool.query(
    `SELECT o.order_no,o.player_id,o.account_id,o.payment_method,o.transaction_id,o.amount_bdt,o.status,o.created_at,p.name AS product
     FROM orders o JOIN products p ON p.id=o.product_id WHERE o.user_id=$1 ORDER BY o.created_at DESC`,
    [req.user.sub]
  );
  res.json({ orders: r.rows });
});

app.get("/api/admin/orders", auth, adminOnly, async (_req, res) => {
  const r = await pool.query(
    `SELECT o.order_no,u.name,u.email,p.name AS product,o.player_id,o.account_id,o.payment_method,o.transaction_id,o.amount_bdt,o.status,o.created_at
     FROM orders o LEFT JOIN users u ON u.id=o.user_id JOIN products p ON p.id=o.product_id ORDER BY o.created_at DESC LIMIT 200`
  );
  res.json({ orders: r.rows });
});

app.patch("/api/admin/orders/:orderNo/status", auth, adminOnly, async (req, res) => {
  const allowed = ["pending_payment","paid","processing","completed","failed","refunded"];
  if (!allowed.includes(req.body?.status)) return res.status(400).json({ error: "Invalid status" });
  const r = await pool.query("UPDATE orders SET status=$1,updated_at=NOW() WHERE order_no=$2 RETURNING order_no,status", [req.body.status, req.params.orderNo]);
  if (!r.rowCount) return res.status(404).json({ error: "Order not found" });
  res.json({ order: r.rows[0] });
});

app.get("/api/admin/customers", auth, adminOnly, async (_req, res) => {
  const r = await pool.query("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 200");
  res.json({ customers: r.rows });
});

app.use(express.static(path.join(__dirname, "../public")));
app.get("*splat", (_req, res) => res.sendFile(path.join(__dirname, "../public/index.html")));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`EFshop running on port ${port}`));
